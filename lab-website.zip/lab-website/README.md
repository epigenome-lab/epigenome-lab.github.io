# OO Lab Website

## 📁 파일 구조

```
lab-website/
│
├── index.html              ← 메인 HTML (모든 페이지 포함)
│
├── css/
│   └── style.css           ← 전체 스타일시트
│
├── js/
│   ├── data.js             ← ★ 데이터 수정 파일 (여기만 수정!)
│   └── main.js             ← SPA 라우팅·검색 로직
│
└── images/
    ├── professor/
    │   └── professor.jpg   ← 교수님 사진
    ├── members/
    │   ├── member1.jpg     ← 연구원 사진 (순서대로)
    │   ├── member2.jpg
    │   └── ...
    ├── alumni/
    │   ├── alumni1.jpg
    │   └── ...
    └── projects/
        ├── project1.jpg
        ├── project2.jpg
        └── project3.jpg
```

---

## ✏️ 내용 수정 방법

모든 데이터는 **`js/data.js`** 한 파일에서 관리합니다.

### 교수님 정보 수정
```js
const PROFESSOR = {
  name:  "홍길동",
  title: "Professor · ...",
  photo: "images/professor/professor.jpg",
  bio:   "...",
  email: "professor@university.ac.kr",
  interests: ["Deep Learning", "..."],
};
```

### 연구원 추가
```js
const MEMBERS = [
  { name: "이름", role: "PhD Student", photo: "images/members/memberN.jpg" },
  // ...
];
```

### 졸업생 추가
```js
const ALUMNI = [
  { name: "이름", role: "MS 2024 → 회사명", photo: "images/alumni/alumniN.jpg" },
];
```

### 프로젝트 수정
```js
const PROJECTS = [
  {
    title: "프로젝트 제목",
    tag:   "분야",
    image: "images/projects/projectN.jpg",
    desc:  "설명...",
    tags:  ["키워드1", "키워드2"],
    period: "2023 – 현재",
  },
];
```

### 논문 추가
```js
const PUBLICATIONS = [
  { year:"2024", title:"...", authors:"...", journal:"..." },
];
```

---

## 🖼️ 사진 없을 때

사진 파일이 없어도 자동으로 이모지 플레이스홀더가 표시됩니다.  
나중에 `images/` 폴더에 파일을 넣으면 자동으로 적용됩니다.

---

## 🚀 실행 방법

`index.html` 파일을 브라우저로 열면 바로 실행됩니다.  
로컬 서버가 필요한 경우:
```bash
# Python
python -m http.server 8080

# Node.js
npx serve .
```

그 후 `http://localhost:8080` 접속.
